﻿const btn2 = document.getElementById('btn2');

let index1 = 0;

const colors = ['red', 'yellow', 'green', 'orange'];

btn2.addEventListener1('click', function onClick() {
    btn2.style1.backgroundColor = colors[index1];
    btn2.style1.color = 'white';

    index1 = index1 >= colors.length - 1 ? 0 : index1 + 1;
});